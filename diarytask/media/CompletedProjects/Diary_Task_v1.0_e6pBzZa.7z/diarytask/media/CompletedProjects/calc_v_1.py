# Калькулятор v 1

doing = input("Какое действие: ")

a = float(input("Введите первое число: "))
b = float(input("Введите второе число: "))

if doing == "+":
	c = a + b
	print("Результат:" + str(c))

elif doing == "-":
	c = a - b
	print("Результат:" + str(c))

elif doing == "*":
	c = a * b
	print("Результат: " + str(c))

elif doing == "/":
	c = a / b
	print("Результат: " + str(c))

else:
	print ("Выбрана не правильная операция")

input()
