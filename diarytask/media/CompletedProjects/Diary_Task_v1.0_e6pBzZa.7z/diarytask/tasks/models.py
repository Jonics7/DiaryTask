from django.db import models


class Category(models.Model):
    """ Категории проектов """
    title = models.CharField('Категория', max_length=150)
    objects = models.Manager()

    def __str__(self):
        return self.title

    class Meta:
        verbose_name = 'Категория'
        verbose_name_plural = 'Категории'



class Project(models.Model):
    """Класс проекта"""
    title = models.CharField('Название проекта', max_length=150)
    task = models.TextField('Техническое задание', blank=True)
    pub_date = models.DateTimeField('Дата публикации', null=True)
    category = models.ForeignKey(Category, verbose_name='Категория', on_delete=models.SET_NULL, null=True)
    upload = models.FileField('Готовый проект', upload_to='CompletedProjects/', blank=True,)
    
    objects = models.Manager()


    class Meta:
        verbose_name = 'Проект'
        verbose_name_plural = 'Проекты'
        ordering = ['category']
    
    def __str__(self):
        return self.title


#category = models.ForeignKey(Category, verbose_name='Категория', on_delete=models.SET_NULL, null=True)
#url = models.SlugField(max_length=130, unique=True)
#upload = models.FileField('Готовый проект', upload_to='CompletedProjects/')